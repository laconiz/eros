package oceanus

import (
	"fmt"
	uuid "github.com/satori/go.uuid"
	"sync"
)

type Peer struct {
	Node
	Nodes    map[string]Node
	Channels map[string]Channel
	Groups   map[string]map[string]Channel
	mutex    sync.RWMutex
}

func (p *Peer) Run(typo, name string) error {

	p.mutex.Lock()
	defer p.mutex.Unlock()

	group, ok := p.Groups[typo]
	if !ok {
		group = map[string]Channel{}
		p.Groups[typo] = group
	}

	if _, ok := group[name]; ok {
		return fmt.Errorf("conflict channel: %s.%s", typo, name)
	}

	channel := &thread{
		ChannelInfo: ChannelInfo{
			UUID: uuid.NewV1().String(),
			Type: typo,
			Name: name,
			Node: *p.Node.Info(),
		},
		Peer: p,
	}
	group[name] = channel

	go channel.run()

	return nil
}

func (p *Peer) direct(typo, key string, msg *Message) error {

	p.mutex.RLock()
	defer p.mutex.RUnlock()

	group, ok := p.Groups[typo]
	if !ok {
		return fmt.Errorf("can not find type: %s", typo)
	}

	channel, ok := group[key]
	if !ok {
		return fmt.Errorf("can not find channel: %s.%s", typo, key)
	}

	return channel.Send(msg)
}

func (p *Peer) Broadcast(typo string) {

}
