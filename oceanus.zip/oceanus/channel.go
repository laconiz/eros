package oceanus

type ChannelInfo struct {
	UUID string
	Type string
	Name string
	Node NodeInfo
}

type Channel interface {
	Info() ChannelInfo
	Send(msg *Message) error
}

type baseChannel struct {
	ChannelInfo
}

func (c *baseChannel) Info() ChannelInfo {
	return c.ChannelInfo
}

type remoteChannel struct {
	baseChannel
	Node Node
}

func (c *remoteChannel) Send(msg *Message) error {
	return c.Node.Send(msg)
}
