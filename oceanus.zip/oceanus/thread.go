package oceanus

import "github.com/laconiz/eros/queue"

type Handler func(*Message)

type thread struct {
	ChannelInfo
	Peer    *Peer
	Queue   *queue.Queue
	Handler Handler
}

func (t *thread) Send(message *Message) {
	t.Queue.Add(message)
}

func (t *thread) run() {

	var exited bool
	var messages []interface{}

	for !exited {
		messages, exited = t.Queue.Pick()
		for _, message := range messages {
			t.Handler(message.(*Message))
		}
	}
}
