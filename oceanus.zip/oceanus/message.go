package oceanus

type Message struct {
	UUID     string
	Receiver *ChannelInfo
	Body     []byte

	peer *Peer
}

func (m *Message) Direct(typo string, key string, raw []byte) {
	m.peer.Send(typo, key, raw)
}

func (m *Message) A() {

}

func main() {
	Run("mail", func(message *Message) {

		mail := message.(*Mail)

		message.Reply(&MailACK{})

		message.LoadBalance()

	})

	Run("fishing", 100001, func(message *Message, channel Channel) {

		channel.Send()

	})
}
