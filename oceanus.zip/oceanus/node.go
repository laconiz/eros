package oceanus

import "github.com/laconiz/eros/network"

type Node interface {
	Info() NodeInfo
	Send(msg *Message)
}

type NodeInfo struct {
	UUID string
	Addr string
}

func (n *NodeInfo) Info() NodeInfo {
	return *n
}

type remoteNode struct {
	NodeInfo
	Session network.Session
}

func (n *remoteNode) Send(msg *Message) error {

}

type localNode struct {
}
